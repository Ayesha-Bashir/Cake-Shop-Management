
import java.util.Objects;


public class CupCake extends Product{

       protected String toppingcolour;
    public CupCake(){
    }
    

    public CupCake( String name, String flavour, double price,int quant,int num,String top) {
        super(name, flavour, price,quant,num);
        this.toppingcolour=top;
        
    }

    public String getToppingcolour() {
        return toppingcolour;
    }

    public void setToppingcolour(String toppingcolour) {
        this.toppingcolour = toppingcolour;
    }

    @Override
     public String toString() {
        return "PRODUCT INFO!" + "\nName:= " + name 
                + "\nFlavour:= " + flavour + "\nPrice:= " + 
                price +"\nQuantity:= "+quant;
    }

      public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        
        final CupCake other = (CupCake) obj;
          if (!Objects.equals(this.name, other.name)) {
            return false;
        }if (!Objects.equals(this.flavour, other.flavour)) {
            return false;
        }
        if (!Objects.equals(this.toppingcolour, other.toppingcolour)) {
            return false;
        }
        if (this.quant != other.quant) {
            return false;
        }
        if (this.price != other.price) {
            return false;
        } 
         if (this.num!= other.num) {
            return false;
        }
        return true;
    }
    

}
