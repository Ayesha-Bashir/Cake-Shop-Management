
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author NR
 */
public class cakehndler {
    
        public void delete(Cake p1){
        ArrayList <Cake> c = read();
        for(Cake i: c)
        {
            if(p1.equals(i)){
                c.remove(i);
             //   i=new Product();
                break;
            }
        }
        
            writeNew(c);
    }
        
    
    public ArrayList<Cake> read(){
        ArrayList <Cake> p = new <Cake> ArrayList();
        try{
            FileReader fr = new FileReader("cake1.txt");
            BufferedReader br = new BufferedReader(fr);
            String line = br.readLine();
            while(line !=null)
            {
                 int pound= Integer.parseInt(line);
                line = br.readLine();
                String name = line;
                line = br.readLine();
                String flavour = line;
                line = br.readLine();               
                double price = Double.parseDouble(line);
                line = br.readLine();
                int quant = Integer.parseInt(line);
                line = br.readLine(); 
                int num= Integer.parseInt(line);
                line = br.readLine(); 
              
                p.add(new Cake(pound,name,flavour,price,quant,num));
            }
            
        }catch(IOException e){
            
        }
        for(Cake i: p)
            System.out.println(i);
        return p;
    }
    
    public void write(Cake p){
        try{
            FileWriter fw = new FileWriter("cake1.txt",true);
            //fw.write("\n");
            fw.write(p.pond+"\n");
            fw.write(p.name+"\n");
            fw.write(p.flavour+"\n");
            fw.write(p.price+"\n");
            fw.write(p.quant+"\n");
            fw.write(p.num+"\n");
            fw.close();
        }catch(IOException e){
            
        }
    }
      public void updatef(Cake p1){
         //  FileHandler f = new FileHandler();
      ArrayList <Cake> p = read();
      for(Cake i: p){
                   if(p1.num==i.num){
                       i.setPond(p1.getPond());
                       i.setName(p1.getName());
                       i.setFlavour(p1.getFlavour());
                       i.setPrice(p1.getPrice());
                       i.setQuant(p1.getQuant());
                       i.setNum(p1.getNum());
                       
                       
                   }
                  writeNew(p);

    }    
    }

    public void writeNew(ArrayList <Cake> p1){
        //Student s;
        FileWriter fw;
        try{
                fw = new FileWriter("cake1.txt");
                //fw.write("\n");
            
        for(Cake s: p1){
                fw.write(s.pond+"\n");
                fw.write(s.name+"\n");
                fw.write(s.flavour+"\n");
                fw.write(s.price+"\n");
                fw.write(s.quant+"\n");
                fw.write(s.num+"\n");

            }
                fw.close();
        }catch(IOException e){
}
        
}}
