
import java.util.Objects;


public class Product {
        protected String name;
    protected String flavour;
    protected double price;
    protected int quant;
    protected int num;
   

    public Product() {
        this.name = null;
        this.flavour = null;
        this.price = 0.0;
    }  
    public Product(String name, String flavour, double price,int quant,int num) {
        this.name = name;
        this.flavour = flavour;
        this.price = price;
        this.quant=quant;
        this.num=num;
    }
    public Product(String name, String flavour,int quant,int num) {
        this.name = name;
        this.flavour = flavour;
        this.quant=quant;
        this.num=num;
    }


    public int getQuant() {
        return quant;
    }

    public void setQuant(int quant) {
        this.quant = quant;
    }


    public String getName() {
        return name;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFlavour() {
        return flavour;
    }

    public void setFlavour(String flavour) {
        this.flavour = flavour;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "PRODUCT INFO!" + "\nName:= " + name 
                + "\nFlavour:= " + flavour + "\nPrice:= " + price +"\nQuantity:= "+quant;
    }
          public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        
        final Product other = (Product) obj;
          if (!Objects.equals(this.name, other.name)) {
            return false;
        }if (!Objects.equals(this.flavour, other.flavour)) {
            return false;
        }
        if (this.quant != other.quant) {
            return false;
        }
        if (this.price != other.price) {
            return false;
        } 
     
          if (this.num!= other.num) {
            return false;
        }
      
        return true;
    }
    


}
