
import java.util.Objects;


public class Cake extends Product{
        protected int pond;

    public Cake() {
        this.pond = 0;
    }
    public Cake(int pond) {
        this.pond = pond;
    }

    public Cake( int pond, String name, String flavour, double price,int quant,int num) {
        super(name, flavour, price, quant,num);
        this.pond = pond;
    }

    
    public void setPond(int pond) {
        this.pond = pond;
    }
    public int getPond() {
        return pond;
    }

        @Override
      public String toString() {
        return "PRODUCT INFO!" + "\nName:= " + name 
                + "\nFlavour:= " + flavour + "\nPrice:= " + price+"\nSize:= "+pond+" Ponds"+"\nQuantity:= "+quant  ;
    }
        @Override
      public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        
        final Cake other = (Cake) obj;
          if (!Objects.equals(this.name, other.name)) {
            return false;
        }if (!Objects.equals(this.flavour, other.flavour)) {
            return false;
        }
       
        if (this.quant != other.quant) {
            return false;
        }
        if (this.price != other.price) {
            return false;
        }
         if (this.num!= other.num) {
            return false;
        }
        return true;
    }
    

}

