
public class Product_management {
         private Product p[];
     private int size;
     private int count;

    public Product_management() {
        this.size = 0;
        this.count = 0;
    }
    public Product_management(int size) {
        this.p = new Product[size];
        this.size = size;
        this.count = count;
    }

    public Product[] getP() {
        return p;
    }

    public void setP(Product[] p) {
        this.p = p;
    }

    public int getSize() {
        return size;
    }

    public int getCount() {
        return count;
    }
     public void add(Product x){
      if(count<size){
       p[count]=x;}
       count++;
   } 
        public void delete(String name){

        for(int i=0;i<size;i++){
            if(name.equalsIgnoreCase(p[i].name)){
                               System.out.println(p[i]);
                p[i]=new Product();
                
                System.out.println("\nProduct_Deleted!");

                
            }}}
     public void modify_name(String name,String newname){

        for(int i=0; i<size;i++){
            if(name.equalsIgnoreCase(p[i].name)){
                System.out.println("\nProduct _Founded!");
                  System.out.println("\nOld_Name:= "+p[i].name);
             //   System.out.println("Enter book's new name");
                p[i].name=newname;
                System.out.println(p[i]);
             System.out.println("\nProduct _Name has been modified!");

            }}}
      public void modify_Price(String name,double newprice){

        for(int i=0; i<size;i++){
            if(name.equalsIgnoreCase(p[i].name)){
                System.out.println("\nProduct _Founded!");
                                   System.out.println("\nOld_Price:= "+p[i].price);
             //   System.out.println("Enter book's new name");
                p[i].price=newprice;
                System.out.println(p[i]);
             System.out.println("\nProduct_Price has been modified!");

                
            }}}
       public void modify_flavore(String name,String newflavour){

        for(int i=0; i<size;i++){
            if(name.equalsIgnoreCase(p[i].name)){
                System.out.println("\nProduct_Founded!");
                                     System.out.println("\nOld_Flavour:= "+p[i].flavour);
             //   System.out.println("Enter book's new name");
                p[i].flavour=newflavour;
                System.out.println(p[i]);
             System.out.println("\nProduct_Flavour has been modified!");

                
            }}}
     
      public String display(){
                //System.out.println("\n\tALL PRODUCTS DETAIL's!\n");
                String info=null;
      for(int  i=0;i<size;i++){
         // System.out.println(p[i]+"\n");
       info=p[i]+"\n";
   }
      return info;}
     

}
