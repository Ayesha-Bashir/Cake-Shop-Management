
import java.util.Objects;


public class Pastries extends Product{
    protected String crustcolour;
    public Pastries() {
    }
   
    public Pastries( String name, String flavour, double price,int quant,int num,String crust) {
        super(name, flavour, price,quant,num);
        this.crustcolour=crust;
        
    }

    public String getCrustcolour() {
        return crustcolour;
    }

    public void setCrustcolour(String crustcolour) {
        this.crustcolour = crustcolour;
    }


    @Override
     public String toString() {
        return "PRODUCT INFO!" + "\nName:= " + name
                + "\nFlavour:= " + flavour + "\nPrice:= " + price+"\nQuantity:= "+quant;
    }
           public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        
        final Pastries other = (Pastries) obj;
          if (!Objects.equals(this.name, other.name)) {
            return false;
        }if (!Objects.equals(this.flavour, other.flavour)) {
            return false;
        }
        if (!Objects.equals(this.crustcolour, other.crustcolour)) {
            return false;
        }
        if (this.quant != other.quant) {
            return false;
        }
        if (this.price != other.price) {
            return false;
        }
          if (this.num!= other.num) {
            return false;
        }
      
        return true;
    }
    

}

