
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;


public class Customerhndler {
        public void delete(Customer c1){
        ArrayList <Customer> c = read();
        for(Customer i: c)
        {
            if(c1.equals(i)){
                c.remove(i);
             //   i=new Product();
                break;
            }
        }
        
            writeNew(c);
    }
        
    
    public ArrayList<Customer> read(){
        ArrayList <Customer> c = new <Customer> ArrayList();
        try{
            FileReader fr = new FileReader("ordersfile3.txt");
            BufferedReader br = new BufferedReader(fr);
            String line = br.readLine();
            while(line !=null)
            { 
               int num= Integer.parseInt(line);
                line = br.readLine();
                String pname = line;
                line = br.readLine();
                String flavour = line;
                line = br.readLine();               
                int quant = Integer.parseInt(line);
                line = br.readLine(); 
                double total = Double.parseDouble(line);
                line = br.readLine();

                String phone = line;
                line = br.readLine(); 
                 
                
                c.add(new Customer(num,pname,flavour,quant,total,phone));
            }
            
        }catch(IOException e){
            
        }
        for(Customer i: c)
            System.out.println(i);
        return c;
    }
    
    public void write(Customer c){
        try{
            FileWriter fw = new FileWriter("ordersfile3.txt",true);
            //fw.write("\n");
            fw.write(c.pnum+"\n");
            fw.write(c.pname+"\n");
            fw.write(c.pflav+"\n");
            fw.write(c.quantity+"\n");
            fw.write(c.total+"\n");
            fw.write(c.pnumber+"\n");
            fw.close();
        }catch(IOException e){
            
        }
    }
    
      public void updatef(Customer c1){
         //  FileHandler f = new FileHandler();
      ArrayList <Customer> c = read();
      for(Customer i: c){
                   if(c1.pnum==i.pnum){
                       i.setPnum(c1.getPnum());
                       i.setPname(c1.getPname());
                       i.setPflav(c1.getPflav());
                       i.setQuantity(c1.getQuantity());
                       i.setTotal(c1.getTotal());
                       i.setPnumber(c1.getPnumber());
                       
                   }
                  writeNew(c);

    }    
    }

    public void writeNew(ArrayList <Customer> c1){
        //Student s;
        FileWriter fw;
        try{
                fw = new FileWriter("ordersfile3.txt");
                //fw.write("\n");1
            
        for(Customer s: c1){
                    fw.write(s.pnum+"\n");
            fw.write(s.pname+"\n");
            fw.write(s.pflav+"\n");
            fw.write(s.quantity+"\n");
            fw.write(s.total+"\n");
            fw.write(s.pnumber+"\n");
        
            }
                fw.close();
        }catch(IOException e){
}
        
}
}
