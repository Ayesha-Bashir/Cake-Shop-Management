
import java.util.Objects;


public class Customer {
        protected String nam;
    protected String pnumber;
    protected double total;
    protected int quantity;
    protected String pname;
    protected String pflav;
    protected String date;
    protected double ppri;
    protected int pnum;
    
         

    public Customer() {
        this.nam = null;
        this.pnumber = null;
        total=0.0;
    } 

    @Override
    public String toString() {
        return "====Customer====="+  "\npnum=" + pnum +"\npname=" + pname +  "\n pflav="
                + pflav  +"\nquantity=" 
                + quantity+"\ntotal=" + total ;
    }

    public Customer(  int number, String nam,String pnumber,String date, double total) {
        this.pnum = number;
        this.nam = nam;
        this.pnumber = pnumber;
        this.total = total;
        this.date=date;
        
    }
    public Customer( int number, String pnam, String pflav,int quantity,  double totall,String nm) {
        this.pnum = number;
        this.total = totall;
        this.quantity = quantity;
        this.pname = pnam;
        this.pflav = pflav;
        this.pnumber=nm;
        this.date=date;
    }

    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }
    public String getPnumber() {
        return pnumber;
    }
    public void setPnumber(String pnumber) {
        this.pnumber = pnumber;
    }
    public int getPnum() {
        return pnum;
    }

    public void setPnum(int pnum) {
        this.pnum = pnum;
    }
   
    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public String getNam() {
        return nam;
    }

    public void setNam(String nam) {
        this.nam = nam;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getPname() {
        return pname;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

    public String getPflav() {
        return pflav;
    }

    public void setPflav(String pflav) {
        this.pflav = pflav;
    }

    public double getPpri() {
        return ppri;
    }

    public void setPpri(double ppri) {
        this.ppri = ppri;
    }

  

   
    public void order(Product p,int quantity){
        
        System.out.println("CUSTOMER NAME:= "+this.nam);
        System.out.println("YOUR ORDER DETAILS!");
        System.out.println(p);
        total= p.price*quantity;
        System.out.println("YOUR TOTAL BILL:= "+total);
        this.setTotal(total);
        //= this.total+z.price;
    }

  
      public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        
        final Customer other = (Customer) obj;
          if (!Objects.equals(this.nam, other.nam)) {
            return false;
        }if (!Objects.equals(this.pname, other.pname)) {
            return false;
        }if (!Objects.equals(this.pnumber, other.pnumber)) {
            return false;
        }if (!Objects.equals(this.pflav, other.pflav)) {
            return false;
        }
        if (this.quantity != other.quantity) {
            return false;
        } if (this.ppri != other.ppri) {
            return false;
        }
        if (this.pnum != other.pnum) {
            return false;
        }
         if (this.total!= other.total) {
            return false;
        }
        return true;
    }

        


}
