
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;


public class Seelshndler {
            public void delete(Customer c1){
        ArrayList <Customer> c = read();
        for(Customer i: c)
        {
            if(c1.pnum==i.pnum){
                if(c1.pnumber.equalsIgnoreCase(i.pnumber)){
                c.remove(i);
             //   i=new Product();
                break;
            }}
        }
        
            writeNew(c);
    }
      public void updatef(Customer c1){
         //  FileHandler f = new FileHandler();
      ArrayList <Customer> c = read();
      for(Customer i: c){
                   if(c1.pnumber.equalsIgnoreCase(i.pnumber)){
                       i.setPnum(c1.getPnum());
                       i.setPname(c1.getPname());
                       i.setPflav(c1.getPflav());
                       i.setQuantity(c1.getQuantity());
                       i.setTotal(c1.getTotal());
                       i.setPnumber(c1.getPnumber());
                       
                   }
                  writeNew(c);

    }    
      }
        public ArrayList<Customer> read(){
        ArrayList <Customer> c = new <Customer> ArrayList();
        try{
            FileReader fr = new FileReader("sel3.txt");
            BufferedReader br = new BufferedReader(fr);
            String line = br.readLine();
            while(line !=null)
            { 
               int num= Integer.parseInt(line);
                line = br.readLine();
    String name = line;
                line = br.readLine();
                String phone = line;
                line = br.readLine(); 
              
                String date = line;
                line = br.readLine();  
                double total = Double.parseDouble(line);
                line = br.readLine();

                 
                
                c.add(new Customer(num,name,phone,date,total));
            }
            
        }catch(IOException e){
            
        }
        for(Customer i: c)
            System.out.println(i);
        return c;
    }
    
    public void write(Customer c){
        try{
            FileWriter fw = new FileWriter("sel3.txt",true);
            //fw.write("\n");
            fw.write(c.pnum+"\n");
            fw.write(c.nam+"\n");
            fw.write(c.pnumber+"\n");
            fw.write(c.date+"\n");
            fw.write(c.total+"\n");
            fw.close();
        }catch(IOException e){
            
        }
    }
    

    public void writeNew(ArrayList <Customer> c1){
        //Student s;
        FileWriter fw;
        try{
                fw = new FileWriter("sel3.txt");
                //fw.write("\n");1
            
        for(Customer s: c1){
                   
            fw.write(s.pnum+"\n");
            fw.write(s.nam+"\n");
            fw.write(s.pnumber+"\n");
            fw.write(s.date+"\n");
            fw.write(s.total+"\n");
        
            }
                fw.close();
        }catch(IOException e){
}
        
}

}
